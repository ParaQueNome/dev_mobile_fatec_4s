package com.example.database2

data class UserData(

    val name:String? = null,
    val telefone:String? = null,
    val email:String? = null


)
